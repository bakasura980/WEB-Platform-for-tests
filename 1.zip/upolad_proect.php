
<html>
<body>
	<form action="commentbox.php" method="post">
	<input type="submit" name = "upload" value="upload">
	</form>
</body>
</html>


