<html>
<body>

<script>setTimeout("location.href = 'reload_reg.php';",0);</script>
</body>
</html>