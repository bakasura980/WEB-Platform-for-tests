<html>
<body>
<script>setTimeout("location.href = 'proect_login.php';",3000);</script>
</body>
</html>