<?php
mysql_connect("localhost", "root", "vi98");
mysql_select_db("comment");


?>