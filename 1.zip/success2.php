<?php
header("Location: Frontpage.php");

?>