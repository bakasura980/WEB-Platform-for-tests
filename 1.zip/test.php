
	</form>
	Test from 10 problems : <form action = "test10.php" method = "POST">
	<input type="submit" name="submit" value="Write student's work">
	</form>
	<br>
	Test from 15 problems : <form action = "test15.php" method = "POST">
	<input type="submit" name="submit" value="Write student's work">
	</form>
	<br>
	Test from 20 problems : <form action = "test20.php" method = "POST">
	<input type="submit" name="submit" value="Write student's work">
	</form>
	<br>
	Test from 25 problems : <form action = "test25.php" method = "POST">
	<input type="submit" name="submit" value="Write student's work">
	</form>

