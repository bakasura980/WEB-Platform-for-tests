<?php
header("Location: commentbox.php");

?>