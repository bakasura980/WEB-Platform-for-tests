<html>
<body>
<?php echo " Your username just exist, please try again"; ?>
<script>setTimeout("location.href = 'proektlogin.php';",2500);</script>
</body>
</html>