
<form method="POST" action="student10.php">
1) <input type="radio" name="10" value="a">a
<input type="radio" name="10" value="b">b
<input type="radio" name="10" value="c">c
<input type="radio" name="10" value="d">d

<br>
<br>
2) <input type="radio" name="20" value="a">a
<input type="radio" name="20" value="b">b
<input type="radio" name="20" value="c">c
<input type="radio" name="20" value="d">d

<br>
<br>
3) <input type="radio" name="30" value="a">a
<input type="radio" name="30" value="b">b
<input type="radio" name="30" value="c">c
<input type="radio" name="30" value="d">d

<br>
<br>
4) <input type="radio" name="40" value="a">a
<input type="radio" name="40" value="b">b
<input type="radio" name="40" value="c">c
<input type="radio" name="40" value="d">d

<br>
<br>
5) <input type="radio" name="50" value="a">a
<input type="radio" name="50" value="b">b
<input type="radio" name="50" value="c">c
<input type="radio" name="50" value="d">d

<br>
<br>
6) <input type="radio" name="60" value="a">a
<input type="radio" name="60" value="b">b
<input type="radio" name="60" value="c">c
<input type="radio" name="60" value="d">d

<br>
<br>
7) <input type="radio" name="70" value="a">a
<input type="radio" name="70" value="b">b
<input type="radio" name="70" value="c">c
<input type="radio" name="70" value="d">d

<br>
<br>
8) <input type="radio" name="80" value="a">a
<input type="radio" name="80" value="b">b
<input type="radio" name="80" value="c">c
<input type="radio" name="80" value="d">d

<br>
<br>
9) <input type="radio" name="90" value="a">a
<input type="radio" name="90" value="b">b
<input type="radio" name="90" value="c">c
<input type="radio" name="90" value="d">d

<br>
<br>
10) <input type="radio" name="100" value="a">a
<input type="radio" name="100" value="b">b
<input type="radio" name="100" value="c">c
<input type="radio" name="100" value="d">d

<br><br>
<input type="submit" name="submit" value="Ready">
</form>

